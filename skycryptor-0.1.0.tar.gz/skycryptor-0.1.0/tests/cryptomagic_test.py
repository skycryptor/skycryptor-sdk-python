#
import unittest

#
from unittest import TestCase


class TestCryptoMagic(TestCase):
    def setUp(self):
        #
        super(TestCryptoMagic, self).setUp()

